export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const { profileText, targetRole } = req.body;
  if (!profileText) return res.status(400).json({ error: 'Profile text required' });

  const targetLine = targetRole ? `\nTarget role/industry: ${targetRole}` : '';

  const prompt = `You are CareerMirror — a brutally honest AI career advisor. Analyse this LinkedIn profile and respond ONLY with valid JSON (no markdown, no preamble, no backticks).

Profile:
${profileText}${targetLine}

Return exactly this JSON structure:
{
  "score": <integer 0-100, market relevance score>,
  "verdict": "<5-8 word honest verdict>",
  "summary": "<2 sentences: overall honest assessment>",
  "critique": "<3-4 sentences of honest, specific criticism. Be direct. Name specific tasks or skills at risk. No sugarcoating.>",
  "ai_risk_level": "<High|Medium|Low>",
  "ai_risk_score": <integer 0-100>,
  "ai_risk_explanation": "<2 sentences: which specific tasks AI can already do right now>",
  "skills_at_risk": [
    {"skill": "<skill name>", "risk": "<High|Medium|Low>"}
  ],
  "strengths": "<2-3 sentences about genuine strengths hard for AI to replicate>",
  "roadmap": [
    {"step": 1, "title": "<short action title>", "description": "<1 sentence specific action>"},
    {"step": 2, "title": "<short action title>", "description": "<1 sentence specific action>"},
    {"step": 3, "title": "<short action title>", "description": "<1 sentence specific action>"}
  ]
}`;

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 1200,
        messages: [{ role: 'user', content: prompt }]
      })
    });

    const data = await response.json();
    if (data.error) return res.status(500).json({ error: data.error.message });

    const text = data.content?.[0]?.text || '';
    const clean = text.replace(/```json|```/g, '').trim();
    const result = JSON.parse(clean);
    return res.status(200).json(result);
  } catch (e) {
    return res.status(500).json({ error: 'Analysis failed: ' + e.message });
  }
}
